import java.util.Scanner;

public class Task {
    private String name;
    private String description;
    private boolean isComplete;
    private static int BaseId=1;
    private int id;
    Scanner scanner=new Scanner(System.in);

    public Task(String name, String description, boolean isComplete) {
        this.name = name;
        this.description = description;
        this.isComplete = isComplete;
        this.id=BaseId++;
    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isComplete() {
        return isComplete;
    }

    public void setComplete(boolean complete) {
        isComplete = complete;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Task{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", isComplete=" + isComplete +
                ", id=" + id +
                '}';
    }
    public void make(){
        System.out.println("enter the name:");
        this.name=scanner.next();
        System.out.println("enter the decroitions");
        this.description=scanner.next();
        System.out.println("Enter the is complete");
        this.isComplete=scanner.hasNext();
        this.id=BaseId++;
    }
    public Task(){make();}


}
