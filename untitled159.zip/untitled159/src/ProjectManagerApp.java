import java.util.ArrayList;
import java.util.Scanner;

public class ProjectManagerApp {
    Scanner scanner=new Scanner(System.in);
    ArrayList<Project>projects;
    public ProjectManagerApp(){
        projects=new ArrayList<>();
        menu();

    }
    public void menu(){
        while (true){
            System.out.println("1. Create a new project");
            System.out.println("2.Add Task To Project");
            System.out.println("3. Mark task as complete");
            System.out.println("4.show tasks");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            switch (choice){
                case 1:
                    projects.add(new Project());
                    break;
                case 2:
                        AddTask();
                    break;
                case 3:

                    break;
                case 4:
                    ShowTasks();

                    break;
                default:
                    System.out.println("Invalid Choice");
                    break;
            }

        }
    }
    public void AddTask(){
        System.out.println("enter the id of project to add task:");
        int id=scanner.nextInt();
        Task task=new Task();
        for (Project project:projects){
            if(project.getId()==id){
                project.getTasks().add(task);
                System.out.println("task added");
                break;
            }
        }

    }
    public void ShowTasks(){
        System.out.println("enter the project id:");
        int id=scanner.nextInt();
        for (Project project:projects){
            if(project.getId()==id){
                System.out.println(project.getTasks().toString());
                break;
            }
        }

    }
}
