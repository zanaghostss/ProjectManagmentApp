import java.util.ArrayList;
import java.util.Scanner;

public class Project {
    private String name;
    private ArrayList<Task>tasks;
    public static int BaseId=1;
    private int id;
    Scanner scanner=new Scanner(System.in);
    public Project(String name){
        this.name=name;
        tasks=new ArrayList<>();

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Task> getTasks() {
        return tasks;
    }

    public void setTasks(ArrayList<Task> tasks) {
        this.tasks = tasks;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Project{" +
                "name='" + name + '\'' +
                ", tasks=" + tasks +
                '}';
    }
    public void make(){
        System.out.println("enter the project name:");
        this.name=scanner.next();
        tasks=new ArrayList<>();
        this.id=BaseId++;
    }
    public Project(){make();}

}